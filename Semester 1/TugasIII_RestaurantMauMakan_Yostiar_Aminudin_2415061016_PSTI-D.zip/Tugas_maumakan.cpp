//TUGAS STRUK
#include <iostream>
#include <string>
using namespace std;
int main (){
int pilmamam, pilmimik, range;
float totalmamam, totalmimik ;
int ongkir = 0;
int diskon = 0;
int Yostiarfix; // (Variabel untuk fix diskon)
char jawaban ;
string nama, makanan, minuman ;

cout <<  " ==================== Selamat Datang ================="<< "\n";
cout <<  " ================== RESTORANT MAUMAKAN ================="<< "\n";
cout <<  "---------------------------------------------------------"<< "\n";

// Masukan Nama
 cout << " Silahkan Masukan Nama Anda = " ; getline (cin, nama);
 // Pengulangan Do - While
// Pilihan Makanan
cout<< "=========================================" << "\n" ;
cout << "MENU MAKANAN" << "\n" ;
cout<< "=========================================" << "\n" ;
cout << "1. Soto Ayam (Rp. 18.000)" << "\n" ;
cout << "2. Nasi Goreng Komplit (Rp. 22.500)" << "\n" ;
cout << "3. Sate Ayam (Rp. 20.000)" << "\n" ;
cout << "=========================================" << "\n" ;
 do {
cout << "Masukan Pilihan Makanan (1/2/3) = "; 
cin >> pilmamam;
switch (pilmamam)
{
case 1 :
    totalmamam += 18000;
    makanan += "Soto Ayam \t \t \t \t \t  Rp. 18.000\n" ;
    break;

case 2 :
    totalmamam += 22500;
    makanan +="Nasi Goreng Komplit \t \t \t \t  Rp. 22.500\n"; 
    break;
case 3:
    totalmamam += 20000;
    makanan += "Sate Ayam \t \t \t \t \t  Rp. 20.000\n"; 

default:
    break;
}
cout << "Apakah ada yang bisa dipesan lagi ?"; 
cout << "\n" <<"Y (Iya) / N (Tidak) = " ; 

cin >> jawaban ;
} while (jawaban == 'y' || jawaban == 'Y' ) ;

// Pilihan Minuman
cout<< "\n" << "=========================================" << "\n" ;
cout << "MENU MINUMAN" << "\n" ;
cout<< "=========================================" << "\n" ;
cout << "1. Jus Mangga (Rp. 10.000)" << "\n" ;
cout << "2. Es Teh (Rp. 5.000)" << "\n" ;
cout << "3. Kopi (Rp. 7.000)" << "\n" ;
cout << "=========================================" << "\n" ;
 do {

cout << "Masukan Pilihan Minuman (1/2/3) = "  ;
cin >> pilmimik;
// OutputMimik
switch (pilmimik)
{
case 1 :
    totalmimik += 10000;
    minuman += "Jus Mangga \t \t \t \t \t  Rp. 10.000\n";
    break;

case 2 :
    totalmimik += 5000;
    minuman += "Es Teh \t \t \t \t \t \t  Rp. 5.000\n";
    break;
case 3 :
    totalmimik += 7000;
    minuman += "Kopi \t \t \t \t \t \t  Rp. 7.000 \n";

default:
    break;
}
cout << "Apakah ada yang bisa dipesan lagi ?"; 
cout << "\n" <<"Y (Iya) / N (Tidak) = "; 
cin >> jawaban ;
} while (jawaban == 'y' || jawaban == 'Y' ) ;
cout<< "\n" << "=========================================" << "\n" ;
cout << "Jarak Dibawah 5KM  =  7.500" "\n" ;
cout << "Jarak Diantara 5KM - 10KM  =  12.500" "\n" ;
cout << "Jarak Dibawah >10KM  =  15.000" "\n" ;


// Input Ongkir
cout << "MASUKAN JARAK PENGIRIMAN (KM) = " ;
cin >>  range;  cout << "Yostiar Aminudin PSTI-D"; 
cout<< "\n" << "=========================================" << "\n" ;

if (range < 5){
    ongkir = 7500 ;
} else if (range >= 5 && 10 <= range)  { 
    ongkir = 12500;
}else {
    ongkir = 15000;
}

// Total Makanan dan Minuman
int total = totalmamam + totalmimik;
// Struk Pembelian
cout <<  "==================== Struk Pembelian ===================="<< "\n";
cout <<  "---------------------------------------------------------"<< "\n";
cout <<  " ====================== MAUMAKAN ====================== "<< "\n";
cout <<  "---------------------------------------------------------"<< "\n";
cout <<  "ITEMS                                                HARGA"<< "\n";
cout <<  "MAKANAN : "<< "\n" << makanan; 
cout <<  "Total Harga Makanan :                             Rp. " << totalmamam << "\n"; 
cout <<  "MINUMAN : "<< "\n" << minuman;
cout <<  "Total Minuman :                                   Rp. " << totalmimik << "\n"; 



// Diskon Ongkir
if (total >= 30000){
    cout << "Mendapatkan Diskon 10 % ! (Pembelanjaan >= 30.000)" << "\n";
 
} else {
    cout << "Tidak Mendapatkan Diskon ! (Pembelanjaan < 30.000)" << "\n";

}
cout << "Nama Pembeli = " << nama << "\n";

// Tampilan Total Harga Dan Ongkir
cout <<  "---------------------------------------------------------"<< "\n";

 cout << "Total Makanan dan Minuman                       Rp. " << total << "\n";
 cout << "Ongkir                                          Rp. " << ongkir << "\n";
 if (total >= 30000) {
// ongkir diskon yostiarfix
 Yostiarfix = ongkir *0.10;
 cout << "Diskon                                          Rp. " << Yostiarfix << "\n";
 }
 cout << "Total                                           Rp. " << (total+ongkir) << "\n";
cout <<  "---------------------------------------------------------"<< "\n";
 // Uang Customer 
 int uangyosti;
cout << "Uang Customer =                                 Rp. "; cin >> uangyosti ;
cout << "";
int uangtotal;
uangtotal =   uangyosti - (total+ongkir) ;
cout << "Uang Kembalian =                                Rp. " << uangtotal  << "\n";


cout <<  "========================================================="<< "\n";
cout <<  " ====================== Terimakasih ====================="<< "\n";
cout <<  " ==================== Selamat Menikmati ================="<< "\n";
cout <<  "---------------------------------------------------------"<< "\n";


 return 0;

}